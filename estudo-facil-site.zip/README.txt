ESTUDO FÁCIL — SITE
====================

Arquivos:
- index.html = página do site
- style.css = visual e responsividade

COMO PUBLICAR
1. Envie index.html e style.css para um serviço de hospedagem de sites estáticos.
2. O arquivo inicial precisa se chamar index.html.
3. Antes de publicar, personalize o nome, textos e o contato.

OBSERVAÇÃO
O formulário desta versão é apenas visual: ele não envia mensagens para um e-mail.
Para receber mensagens de verdade, conecte o formulário a um serviço de formulários ou a um backend.

O site não inclui sistema de pagamento. Se você decidir vender materiais, configure pagamentos e contas com a ajuda de um responsável quando a plataforma exigir maioridade.
